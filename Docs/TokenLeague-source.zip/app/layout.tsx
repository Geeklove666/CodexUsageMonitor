import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Token League · Codex 用量排行榜",
  description: "每一个 Token，都是创造的痕迹。Codex 有效 Token 日榜、周榜、月榜；ChatGPT 登录、自定义公开 ID、自愿参与。",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN">
      <body className="antialiased">{children}</body>
    </html>
  );
}
