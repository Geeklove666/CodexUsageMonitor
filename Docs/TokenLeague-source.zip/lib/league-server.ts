import { env } from "cloudflare:workers";
import { getChatGPTUser } from "@/app/chatgpt-auth";
import { normalizeCode, normalizeHandle, periodBounds, validateUsage } from "./league-rules.mjs";
class Problem extends Error { constructor(public status: number, message: string) { super(message); } }
const json = (data: unknown, status = 200) => Response.json(data, { status, headers: { "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" } });
const db = () => { if (!env.DB) throw new Problem(503, "排行榜存储暂时不可用，请稍后再试"); return env.DB; };
const random = () => Array.from(crypto.getRandomValues(new Uint8Array(32)), x => x.toString(16).padStart(2, "0")).join("");
async function hash(value: string) { return Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value))), x => x.toString(16).padStart(2,"0")).join(""); }
async function user() { const u = await getChatGPTUser(); if (!u) throw new Problem(401, "请先使用 ChatGPT 登录"); return u.userId; }
function origin(request: Request, required = false) {
  const value = request.headers.get("origin");
  if ((required && !value) || (value && value !== new URL(request.url).origin)) throw new Problem(403, "请求来源不正确");
}
async function body(request: Request) {
  origin(request);
  if (!request.headers.get("content-type")?.startsWith("application/json")) throw new Problem(415, "请使用 JSON 格式");
  const reader = request.body?.getReader(); if (!reader) throw new Problem(400,"请求内容为空");
  const chunks: Uint8Array[] = []; let size = 0;
  for (;;) { const {done,value} = await reader.read(); if (done) break; size += value.length; if (size>16384) { await reader.cancel(); throw new Problem(413,"请求内容过大"); } chunks.push(value); }
  const bytes = new Uint8Array(size); let offset = 0; for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}
  const text = new TextDecoder().decode(bytes);
  try { return JSON.parse(text); } catch { throw new Problem(400, "JSON 格式不正确"); }
}
async function rateLimit(request: Request, purpose: string, maximum: number) {
  const epoch = Math.floor(Date.now() / 60_000), ip = request.headers.get("cf-connecting-ip") ?? "local";
  const key = `${purpose}:${epoch}:${await hash(ip)}`;
  const result = await db().prepare("INSERT INTO league_request_limits(key,hits,expires_at) VALUES (?,1,?) ON CONFLICT(key) DO UPDATE SET hits=hits+1 RETURNING hits").bind(key,Date.now()+120_000).first<{hits:number}>();
  if ((result?.hits ?? 0) > maximum) throw new Problem(429,"操作过于频繁，请稍后重试");
  await db().batch([db().prepare("DELETE FROM league_request_limits WHERE expires_at < ?").bind(Date.now()),db().prepare("DELETE FROM league_pairing WHERE expires_at < ?").bind(Date.now())]);
}
async function activeDevice(request: Request) {
  const token = request.headers.get("authorization")?.match(/^Bearer ([a-f0-9]{64})$/)?.[1];
  if (!token) throw new Problem(401,"设备尚未连接或授权已失效");
  const device = await db().prepare("SELECT d.id,d.user_id FROM league_devices d JOIN league_profiles p ON p.user_id=d.user_id WHERE d.token_hash=? AND d.revoked_at IS NULL AND d.expires_at>? AND p.visible=1").bind(await hash(token),Date.now()).first<{id:string,user_id:string}>();
  if (!device) throw new Problem(401,"设备授权已失效，请重新连接"); return device;
}
export async function handle(request: Request): Promise<Response> {
  try {
    const url = new URL(request.url), path = url.pathname, method = request.method, now = Date.now();
    if (method === "GET" && path === "/api/leaderboard") {
      const period = url.searchParams.get("period") ?? "day", bounds = periodBounds(period);
      const aggregate = "SELECT p.handle, SUM(u.tokens) AS tokens, MAX(u.updated_at) AS synced_at FROM league_profiles p JOIN league_daily_usage u ON u.user_id=p.user_id WHERE p.visible=1 AND u.day>=? AND u.day<=? GROUP BY p.user_id HAVING SUM(u.tokens)>0";
      const rows = await db().prepare(`SELECT *, RANK() OVER (ORDER BY tokens DESC) AS rank FROM (${aggregate}) ORDER BY tokens DESC,handle ASC LIMIT 100`).bind(bounds.start,bounds.end).all();
      const summary = await db().prepare(`SELECT COUNT(*) AS participants, COALESCE(SUM(tokens),0) AS tokens FROM (${aggregate})`).bind(bounds.start,bounds.end).first();
      return json({period,...bounds,entries:rows.results,summary,updatedAt:now,source:"本机同步 · 有效 Token（不含缓存输入）"});
    }
    if (method === "GET" && path === "/api/session") {
      const u = await getChatGPTUser(); if (!u) return json({signedIn:false});
      const profile = await db().prepare("SELECT handle,visible FROM league_profiles WHERE user_id=?").bind(u.userId).first();
      const devices = await db().prepare("SELECT id,label,last_used_at FROM league_devices WHERE user_id=? AND revoked_at IS NULL AND expires_at>? ORDER BY last_used_at DESC").bind(u.userId,now).all();
      return json({signedIn:true,profile,devices:devices.results});
    }
    if (method === "POST" && path === "/api/profile") {
      origin(request,true); const id = await user(), value = await body(request), handle = normalizeHandle(value.handle);
      if (typeof value.visible !== "boolean") throw new Problem(400,"请确认是否公开参与排行榜");
      const occupied = await db().prepare("SELECT user_id FROM league_profiles WHERE handle=?").bind(handle).first<{user_id:string}>();
      if (occupied && occupied.user_id !== id) throw new Problem(409,"这个公开 ID 已被使用，请换一个");
      try { await db().prepare("INSERT INTO league_profiles(user_id,handle,visible,updated_at) VALUES (?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET handle=excluded.handle,visible=excluded.visible,updated_at=excluded.updated_at").bind(id,handle,value.visible?1:0,now).run(); }
      catch { throw new Problem(409,"公开 ID 保存失败，请换一个 ID 后重试"); }
      if (!value.visible) await db().prepare("UPDATE league_devices SET revoked_at=? WHERE user_id=? AND revoked_at IS NULL").bind(now,id).run();
      return json({handle,visible:value.visible});
    }
    if (method === "POST" && path === "/api/device/start") {
      const value = await body(request); await rateLimit(request,"pair",5);
      const code = Array.from(crypto.getRandomValues(new Uint8Array(8)),x => "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"[x % 32]).join("");
      const deviceCode = random(), expires = now+600_000;
      const label = typeof value.label === "string" ? value.label.slice(0,40).replace(/[\x00-\x1F]/g,"") : "Codex Usage Monitor · Mac";
      await db().prepare("INSERT INTO league_pairing(device_hash,code,label,expires_at) VALUES (?,?,?,?)").bind(await hash(deviceCode),code,label,expires).run();
      return json({deviceCode,userCode:code.slice(0,4)+"-"+code.slice(4),verificationUri:url.origin+"/connect?code="+code,expiresIn:600,interval:5});
    }
    if (method === "GET" && path === "/api/device/preview") {
      await user(); const code = normalizeCode(url.searchParams.get("code"));
      const entry = await db().prepare("SELECT label,expires_at,user_id,claimed_at FROM league_pairing WHERE code=? AND expires_at>?").bind(code,now).first<{label:string,expires_at:number,user_id:string|null,claimed_at:number|null}>();
      if (!entry) throw new Problem(404,"连接码已过期或不存在，请在软件中重新连接");
      return json({label:entry.label,expiresAt:entry.expires_at,approved:!!entry.user_id});
    }
    if (method === "POST" && path === "/api/device/approve") {
      origin(request,true); const id = await user(), value = await body(request), code = normalizeCode(value.code);
      const profile = await db().prepare("SELECT visible FROM league_profiles WHERE user_id=?").bind(id).first<{visible:number}>();
      if (!profile?.visible) throw new Problem(409,"请先设置公开 ID 并确认参与排行榜");
      const changed = await db().prepare("UPDATE league_pairing SET user_id=? WHERE code=? AND user_id IS NULL AND claimed_at IS NULL AND expires_at>?").bind(id,code,now).run();
      if (!changed.meta.changes) throw new Problem(409,"连接码已被使用或已过期"); return json({approved:true});
    }
    if (method === "POST" && path === "/api/device/token") {
      const value = await body(request); if (typeof value.deviceCode !== "string" || !/^[a-f0-9]{64}$/.test(value.deviceCode)) throw new Problem(400,"设备连接码不正确");
      const hashed = await hash(value.deviceCode); await rateLimit(request,"poll:"+hashed,30);
      const entry = await db().prepare("SELECT user_id,label,claimed_at FROM league_pairing WHERE device_hash=? AND expires_at>?").bind(hashed,now).first<{user_id:string|null,label:string,claimed_at:number|null}>();
      if (!entry) throw new Problem(410,"设备连接已过期，请重新连接");
      if (!entry.user_id) return json({error:"authorization_pending"},428);
      if (entry.claimed_at) throw new Problem(409,"设备连接码已使用");
      const claimed = await db().prepare("UPDATE league_pairing SET claimed_at=? WHERE device_hash=? AND claimed_at IS NULL").bind(now,hashed).run();
      if (!claimed.meta.changes) throw new Problem(409,"设备连接码已使用");
      const token = random(), deviceId = crypto.randomUUID();
      await db().batch([db().prepare("UPDATE league_devices SET revoked_at=? WHERE user_id=? AND revoked_at IS NULL").bind(now,entry.user_id),db().prepare("INSERT INTO league_devices(id,user_id,token_hash,label,expires_at,last_used_at) VALUES (?,?,?,?,?,?)").bind(deviceId,entry.user_id,await hash(token),entry.label,now+90*86400_000,now)]);
      const profile = await db().prepare("SELECT handle FROM league_profiles WHERE user_id=?").bind(entry.user_id).first();
      return json({accessToken:token,deviceId,profile,expiresIn:90*86400});
    }
    if (method === "POST" && path === "/api/usage") {
      const device = await activeDevice(request), days = validateUsage(await body(request)); await rateLimit(request,"sync:"+device.id,4);
      await db().batch([...days.map((d:{date:string,tokens:number}) => db().prepare("INSERT INTO league_daily_usage(user_id,day,tokens,updated_at) VALUES (?,?,?,?) ON CONFLICT(user_id,day) DO UPDATE SET tokens=MAX(tokens,excluded.tokens),updated_at=excluded.updated_at").bind(device.user_id,d.date,d.tokens,now)),db().prepare("UPDATE league_devices SET last_used_at=? WHERE id=?").bind(now,device.id)]);
      return json({accepted:days.length,syncedAt:now});
    }
    if (method === "POST" && path === "/api/device/revoke") {
      origin(request,true); const id = await user(), value = await body(request);
      await db().prepare("UPDATE league_devices SET revoked_at=? WHERE id=? AND user_id=?").bind(now,String(value.id),id).run(); return json({revoked:true});
    }
    if (method === "POST" && path === "/api/device/disconnect") {
      const device = await activeDevice(request); await body(request);
      await db().prepare("UPDATE league_devices SET revoked_at=? WHERE id=?").bind(now,device.id).run();
      return json({revoked:true});
    }
    if (method === "POST" && path === "/api/withdraw") {
      origin(request,true); const id = await user(); await body(request);
      await db().batch([db().prepare("UPDATE league_profiles SET visible=0,updated_at=? WHERE user_id=?").bind(now,id),db().prepare("UPDATE league_devices SET revoked_at=? WHERE user_id=? AND revoked_at IS NULL").bind(now,id)]); return json({withdrawn:true});
    }
    return json({error:"接口不存在"},404);
  } catch(error) {
    if (error instanceof Problem) return json({error:error.message},error.status);
    if (error instanceof Error && /^(请选择|公开 ID|这个 ID|上传格式|仅接受|Token 数值)/.test(error.message)) return json({error:error.message},400);
    return json({error:"服务暂时不可用，请稍后重试"},503);
  }
}
