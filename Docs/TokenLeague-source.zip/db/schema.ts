import { sqliteTable, text, integer, primaryKey, index, uniqueIndex } from "drizzle-orm/sqlite-core";
export const profiles = sqliteTable("league_profiles", {
  userId: text("user_id").primaryKey(), handle: text("handle").notNull(),
  visible: integer("visible").notNull().default(0), updatedAt: integer("updated_at").notNull(),
}, t => [uniqueIndex("league_handle_unique").on(t.handle)]);
export const usage = sqliteTable("league_daily_usage", {
  userId: text("user_id").notNull(), day: text("day").notNull(),
  tokens: integer("tokens").notNull(), updatedAt: integer("updated_at").notNull(),
}, t => [primaryKey({ columns: [t.userId, t.day] }), index("league_usage_day").on(t.day)]);
export const devices = sqliteTable("league_devices", {
  id: text("id").primaryKey(), userId: text("user_id").notNull(),
  tokenHash: text("token_hash").notNull(), label: text("label").notNull(),
  expiresAt: integer("expires_at").notNull(), revokedAt: integer("revoked_at"), lastUsedAt: integer("last_used_at").notNull(),
}, t => [uniqueIndex("league_token_unique").on(t.tokenHash), index("league_device_user").on(t.userId)]);
export const pairing = sqliteTable("league_pairing", {
  deviceHash: text("device_hash").primaryKey(), code: text("code").notNull(),
  userId: text("user_id"), label: text("label").notNull(),
  expiresAt: integer("expires_at").notNull(), claimedAt: integer("claimed_at"),
}, t => [uniqueIndex("league_pair_code").on(t.code)]);
export const limits = sqliteTable("league_request_limits", {
  key: text("key").primaryKey(), hits: integer("hits").notNull(), expiresAt: integer("expires_at").notNull(),
});
