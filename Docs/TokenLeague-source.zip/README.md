# Token League

Codex Usage Monitor 的公开有效 Token 排行榜。Sites 内置域名托管，ChatGPT 官方登录，Cloudflare D1 持久化。

## 产品行为

- 日榜、周榜、月榜按北京时间自然周期；有效 Token 不含缓存输入。
- 用户主动设置唯一公开 ID 并同意参与；登录不等同于验证 Plus 订阅。
- 浏览器批准十分钟设备码，软件使用独立的 90 天设备凭据同步；OpenAI OAuth 凭据不上传。
- 一账号一台上传设备，后续连接替换旧设备；每日绝对计数幂等合并。
- 只公开 ID 和计数，不存邮箱、对话或代码；撤销设备或退出榜单后停止同步，退出后立即隐藏记录。

## 开发

使用 Node 22.13+ 与 npm。安装和部署遵循 Sites 插件流程；`npm run dev -- --port 5187 --hostname 127.0.0.1` 启动本地预览。

`node --test tests/rules.test.mjs` 验证统计周期、ID 与数据校验。`node tests/api-smoke.mjs` 只能指向 loopback 预览，使用模拟登录和本地数据库执行完整连接／同步／撤销流程，绝不能对生产站点运行。

`npm run db:generate` 生成版本化迁移；不要修改已应用的迁移，也不要在生产数据库注入测试榜单。生产认证由 Sites 提供，本地模拟登录不会包含在生产构建内。

设备协议见主项目 `Docs/Leaderboard.md`。源码中不包含服务凭据。
