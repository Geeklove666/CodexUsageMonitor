// Runs only against an explicitly selected loopback preview with mock ChatGPT identity.
import assert from "node:assert/strict";
import { shanghaiDay, SOURCE } from "../lib/league-rules.mjs";
const base=process.env.LEAGUE_TEST_URL??"http://127.0.0.1:5187";
assert.equal(new URL(base).hostname,"127.0.0.1","Never run fixture writes against a hosted Site");
let cookie=""; let assertions=0;
async function call(path,data,token,expected=200,customOrigin=base){
  const headers={}; if(cookie)headers.Cookie=cookie;if(data!==undefined){headers["Content-Type"]="application/json";headers.Origin=customOrigin;}if(token)headers.Authorization="Bearer "+token;
  const r=await fetch(base+path,{method:data===undefined?"GET":"POST",headers,body:data===undefined?undefined:JSON.stringify(data)});
  assert.equal(r.status,expected,`${path}: expected ${expected}, received ${r.status}: ${r.status===expected?"":await r.text()}`);assertions++;const text=await r.text();try{return JSON.parse(text);}catch{return {error:text};}
}
await call("/api/profile",{handle:"qa_creator",visible:true},null,401);
await call("/api/usage",{source:SOURCE,days:[]},null,401);
await call("/api/leaderboard?period=year",undefined,null,400);
const login=await fetch(base+"/signin-with-chatgpt?return_to=/",{redirect:"manual"});
cookie=(login.headers.getSetCookie?.()??[]).map(c=>c.split(";")[0]).join("; ");
assert.ok(cookie,"local mock login must issue a cookie");
const session=await call("/api/session");assert.equal(session.signedIn,true);assertions++;
await call("/api/profile",{handle:"QA_Creator",visible:true});
await call("/api/profile",{handle:"qa_creator",visible:true},null,403,"https://evil.invalid");
const pairing=await call("/api/device/start",{label:"QA fixture Mac"});
const pending=await call("/api/device/token",{deviceCode:pairing.deviceCode},null,428);assert.equal(pending.error,"authorization_pending");assertions++;
await call("/api/device/approve",{code:pairing.userCode});
await call("/api/device/approve",{code:pairing.userCode},null,409);
const device=await call("/api/device/token",{deviceCode:pairing.deviceCode});
assert.equal(device.accessToken.length,64);assertions++;
await call("/api/device/token",{deviceCode:pairing.deviceCode},null,409);
const day=shanghaiDay();const payload={source:SOURCE,days:[{date:day,tokens:12345}]};
// A persistent preview may contain this fixture's earlier days. Preserve that baseline.
const baseline={};
for(const period of ["day","week","month"]){const board=await call("/api/leaderboard?period="+period);baseline[period]=board.entries.find(e=>e.handle==="qa_creator")?.tokens??0;}
await call("/api/usage",payload,device.accessToken);
await call("/api/usage",payload,device.accessToken);
await call("/api/usage",{source:SOURCE,days:[{date:day,tokens:100}]},device.accessToken);
for(const period of ["day","week","month"]){const board=await call("/api/leaderboard?period="+period);const entry=board.entries.find(e=>e.handle==="qa_creator");assert.equal(entry.tokens,baseline[period]-baseline.day+Math.max(baseline.day,12345),"absolute sync must not add or decrease counters");assertions++;assert.ok(!JSON.stringify(board).includes("sites.test"));assert.ok(!JSON.stringify(board).includes("user_id"));assertions+=2;}
await call("/api/withdraw",{});
await call("/api/usage",payload,device.accessToken,401);
const after=await call("/api/leaderboard?period=day");assert.equal(after.entries.some(e=>e.handle==="qa_creator"),false);assertions++;
console.log(`${assertions} API assertions passed: mock sign-in, profile, CSRF, pairing, replay protection, idempotent counts, all periods and withdrawal.`);
