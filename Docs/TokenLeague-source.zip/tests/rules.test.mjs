import test from "node:test";
import assert from "node:assert/strict";
import { periodBounds, shanghaiDay, normalizeHandle, normalizeCode, validateUsage, SOURCE } from "../lib/league-rules.mjs";
test("北京时间跨零点与自然周起点",()=>{
  const now=new Date("2026-10-25T16:00:00Z");
  assert.equal(shanghaiDay(now),"2026-10-26");
  assert.deepEqual(periodBounds("week",now),{start:"2026-10-26",end:"2026-10-26",timezone:"Asia/Shanghai"});
  assert.equal(periodBounds("week",new Date("2026-10-25T12:00:00Z")).start,"2026-10-19");
});
test("月榜正确处理月初与跨年",()=>{
  assert.equal(periodBounds("month",new Date("2025-12-31T16:00:00Z")).start,"2026-01-01");
  assert.throws(()=>periodBounds("year"));
});
test("ID 统一小写并拒绝注入、短 ID 与保留名",()=>{
  assert.equal(normalizeHandle("Creator_666"),"creator_666");
  for(const name of ["ab","admin","OPENAI","<script>","with space","x".repeat(25),null]) assert.throws(()=>normalizeHandle(name));
});
test("同步仅接受整数真实计数与确定口径",()=>{
  const now=new Date("2026-10-30T12:00:00Z");
  assert.deepEqual(validateUsage({source:SOURCE,days:[{date:"2026-10-30",tokens:0}]},now),[{date:"2026-10-30",tokens:0}]);
  for(const tokens of [-1,1.5,Number.MAX_SAFE_INTEGER,NaN,"20"]) assert.throws(()=>validateUsage({source:SOURCE,days:[{date:"2026-10-30",tokens}]},now));
  assert.throws(()=>validateUsage({source:"credits-estimate",days:[{date:"2026-10-30",tokens:1}]},now));
});
test("拒绝未来、过期、重复和无效日期",()=>{
  const now=new Date("2026-10-30T12:00:00Z");
  for(const date of ["2026-10-31","2026-09-01","2026-10-00","2026-10-99","invalid"]) assert.throws(()=>validateUsage({source:SOURCE,days:[{date,tokens:1}]},now));
  assert.throws(()=>validateUsage({source:SOURCE,days:[{date:"2026-10-30",tokens:1},{date:"2026-10-30",tokens:2}]},now));
});
test("连接码归一化不改变有效码",()=>{assert.equal(normalizeCode("abcd-efgh"),"ABCDEFGH");assert.equal(normalizeCode(null),"");});
