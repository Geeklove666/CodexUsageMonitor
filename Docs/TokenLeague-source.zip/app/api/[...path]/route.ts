import { handle } from "@/lib/league-server";
export const dynamic = "force-dynamic";
export const GET = handle;
export const POST = handle;
