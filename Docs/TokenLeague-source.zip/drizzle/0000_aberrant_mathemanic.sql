CREATE TABLE `league_devices` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`token_hash` text NOT NULL,
	`label` text NOT NULL,
	`expires_at` integer NOT NULL,
	`revoked_at` integer,
	`last_used_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `league_token_unique` ON `league_devices` (`token_hash`);--> statement-breakpoint
CREATE INDEX `league_device_user` ON `league_devices` (`user_id`);--> statement-breakpoint
CREATE TABLE `league_request_limits` (
	`key` text PRIMARY KEY NOT NULL,
	`hits` integer NOT NULL,
	`expires_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `league_pairing` (
	`device_hash` text PRIMARY KEY NOT NULL,
	`code` text NOT NULL,
	`user_id` text,
	`label` text NOT NULL,
	`expires_at` integer NOT NULL,
	`claimed_at` integer
);
--> statement-breakpoint
CREATE UNIQUE INDEX `league_pair_code` ON `league_pairing` (`code`);--> statement-breakpoint
CREATE TABLE `league_profiles` (
	`user_id` text PRIMARY KEY NOT NULL,
	`handle` text NOT NULL,
	`visible` integer DEFAULT 0 NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `league_handle_unique` ON `league_profiles` (`handle`);--> statement-breakpoint
CREATE TABLE `league_daily_usage` (
	`user_id` text NOT NULL,
	`day` text NOT NULL,
	`tokens` integer NOT NULL,
	`updated_at` integer NOT NULL,
	PRIMARY KEY(`user_id`, `day`)
);
--> statement-breakpoint
CREATE INDEX `league_usage_day` ON `league_daily_usage` (`day`);