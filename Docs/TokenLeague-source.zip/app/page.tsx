import League from "./league";
export default function Page() { return <League />; }
