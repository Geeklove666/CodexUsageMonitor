import League from "../league";
export default function ConnectPage() { return <League connecting />; }
